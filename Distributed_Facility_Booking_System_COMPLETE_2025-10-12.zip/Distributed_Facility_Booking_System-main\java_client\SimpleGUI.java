import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.util.List;

public class SimpleGUI extends JFrame {
    // Component references for button actions
    private JComboBox<String> queryFacilityCombo;
    private JTextField queryDaysField;
    private JTextArea queryResultsArea;
    private JComboBox<String> bookFacilityCombo;
    private JTextField bookDateField;
    private JTextField bookTimeField;
    private JTextField bookDurationField;
    private JTextArea bookResultsArea;
    private JTextField changeIdField;
    private JTextField changeDateField;
    private JTextField changeTimeField;
    private JTextField cancelField;
    private JTextArea operationsResultsArea;
    private JTextArea changeResultArea;
    
    // Data storage for bookings
    private List<Booking> bookings = new ArrayList<>();
    private Map<String, Integer> originalDurations = new HashMap<>();
    private int nextBookingId = 1;
    
    // Booking class to store reservation data
    class Booking {
        String id;
        String facility;
        String date;
        String startTime;
        int duration;
        
        Booking(String id, String facility, String date, String startTime, int duration) {
            this.id = id;
            this.facility = facility;
            this.date = date;
            this.startTime = startTime;
            this.duration = duration;
        }
    }
    public SimpleGUI() {
        setTitle("Facility Booking System - Java Client");
        setSize(1800, 1400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        
        // Top panel with dark blue background matching Python version
        JPanel topPanel = new JPanel();
        topPanel.setBackground(new Color(34, 34, 59));
        topPanel.setPreferredSize(new Dimension(1800, 90));
        JLabel title = new JLabel("Facility Booking System");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Arial", Font.BOLD, 36));
        topPanel.add(title);
        
        JLabel serverInfo = new JLabel("Server: 8.148.159.175:8080");
        serverInfo.setForeground(new Color(201, 173, 167));
        serverInfo.setFont(new Font("Arial", Font.PLAIN, 20));
        topPanel.add(serverInfo);
        add(topPanel, BorderLayout.NORTH);
        
        // Tabbed pane matching Python version layout
        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(new Font("Arial", Font.BOLD, 20));
        tabs.addTab("Query", createQueryPanel());
        tabs.addTab("Book", createBookPanel());
        tabs.addTab("Change", createChangePanel());
        tabs.addTab("Operations", createOperationsPanel());
        add(tabs, BorderLayout.CENTER);
        
        // Log area at bottom with dark theme
        JTextArea logArea = new JTextArea(12, 150);
        logArea.setBackground(new Color(35, 36, 58));
        logArea.setForeground(new Color(224, 225, 221));
        logArea.setFont(new Font("Consolas", Font.PLAIN, 16));
        logArea.setText("[22:35:12] Java GUI Client Started Successfully!\n[22:35:12] Interface matches Python version design!\n[22:35:12] Ready for facility booking operations...\n[22:35:12] All buttons are now functional!\n[22:35:12] Window size increased to 1800x1400 for better usability");
        logArea.setEditable(false);
        JScrollPane logScrollPane = new JScrollPane(logArea);
        logScrollPane.setPreferredSize(new Dimension(1800, 200));
        add(logScrollPane, BorderLayout.SOUTH);
    }
    
    private JPanel createQueryPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));
        panel.setBackground(Color.WHITE);
        
        JLabel title = new JLabel("Query Facility Availability");
        title.setFont(new Font("Arial", Font.BOLD, 32));
        title.setForeground(new Color(34, 34, 59));
        panel.add(title);
        
        panel.add(Box.createVerticalStrut(25));
        
        // Facility selection
        JPanel facilityPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        facilityPanel.setBackground(Color.WHITE);
        JLabel facilityLabel = new JLabel("Facility Name:");
        facilityLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        facilityPanel.add(facilityLabel);
        String[] facilities = {"Conference_Room_A", "Conference_Room_B", "Lab_101", "Lab_102", "Auditorium"};
        queryFacilityCombo = new JComboBox<>(facilities);
        queryFacilityCombo.setPreferredSize(new Dimension(350, 45));
        queryFacilityCombo.setFont(new Font("Arial", Font.PLAIN, 18));
        facilityPanel.add(queryFacilityCombo);
        panel.add(facilityPanel);
        
        panel.add(Box.createVerticalStrut(15));
        
        // Query days
        JPanel daysPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        daysPanel.setBackground(Color.WHITE);
        JLabel daysLabel = new JLabel("Query Days (comma separated, 0=today):");
        daysLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        daysPanel.add(daysLabel);
        queryDaysField = new JTextField("0,1,2", 20);
        queryDaysField.setFont(new Font("Arial", Font.PLAIN, 14));
        queryDaysField.setPreferredSize(new Dimension(200, 35));
        daysPanel.add(queryDaysField);
        panel.add(daysPanel);
        
        panel.add(Box.createVerticalStrut(25));
        
        // Query button
        JButton queryButton = new JButton("Query Availability");
        queryButton.setBackground(new Color(74, 78, 105));
        queryButton.setForeground(Color.WHITE);
        queryButton.setPreferredSize(new Dimension(220, 50));
        queryButton.setFont(new Font("Arial", Font.BOLD, 16));
        queryButton.setFocusPainted(false);
        queryButton.addActionListener(e -> {
            String facility = (String) queryFacilityCombo.getSelectedItem();
            String days = queryDaysField.getText();
            
            StringBuilder result = new StringBuilder();
            result.append("Querying ").append(facility).append(" for days: ").append(days).append("\n\n");
            
            // Get current bookings for this facility - search all dates for now
            List<Booking> facilityBookings = new ArrayList<>();
            for (Booking booking : bookings) {
                if (booking.facility.equals(facility)) {
                    facilityBookings.add(booking);
                }
            }
            
            // Generate all 24 hour time slots (00:00 - 24:00)
            String[] allTimeSlots = {
                "00:00 - 01:00", "01:00 - 02:00", "02:00 - 03:00", "03:00 - 04:00",
                "04:00 - 05:00", "05:00 - 06:00", "06:00 - 07:00", "07:00 - 08:00",
                "08:00 - 09:00", "09:00 - 10:00", "10:00 - 11:00", "11:00 - 12:00",
                "12:00 - 13:00", "13:00 - 14:00", "14:00 - 15:00", "15:00 - 16:00",
                "16:00 - 17:00", "17:00 - 18:00", "18:00 - 19:00", "19:00 - 20:00",
                "20:00 - 21:00", "21:00 - 22:00", "22:00 - 23:00", "23:00 - 24:00"
            };
            
            // Show all bookings for this facility
            result.append("=== Facility: ").append(facility).append(" ===\n");
            result.append("All bookings for this facility:\n");
            
            if (facilityBookings.isEmpty()) {
                result.append("No bookings found - All 24 hours available for all dates!\n");
                result.append("Available slots (").append(allTimeSlots.length).append(" total):\n");
                for (String slot : allTimeSlots) {
                    result.append("  ").append(slot).append("\n");
                }
            } else {
                result.append("Current bookings:\n");
                for (Booking booking : facilityBookings) {
                    int endHour = Integer.parseInt(booking.startTime.split(":")[0]) + booking.duration;
                    result.append("  BOOKED: ").append(booking.date).append(" ")
                          .append(booking.startTime).append(" - ")
                          .append(String.format("%02d:00", endHour))
                          .append(" (ID: ").append(booking.id).append(")\n");
                }
                
                // Group bookings by date to show availability per date
                Map<String, List<Booking>> bookingsByDate = new HashMap<>();
                for (Booking booking : facilityBookings) {
                    bookingsByDate.computeIfAbsent(booking.date, k -> new ArrayList<>()).add(booking);
                }
                
                result.append("\nAvailability by date:\n");
                Set<String> allDates = new HashSet<>(bookingsByDate.keySet());
                // Also show requested query dates
                String[] queryDays = days.split(",");
                for (String dayStr : queryDays) {
                    String queryDate = "2025-10-" + String.format("%02d", 13 + Integer.parseInt(dayStr.trim()));
                    allDates.add(queryDate);
                }
                
                for (String date : allDates) {
                    result.append("\n--- Date: ").append(date).append(" ---\n");
                    List<Booking> dateBookings = bookingsByDate.getOrDefault(date, new ArrayList<>());
                    
                    if (dateBookings.isEmpty()) {
                        result.append("All 24 hours available!\n");
                    } else {
                        // Calculate occupied hours for this date
                        Set<Integer> occupiedHours = new HashSet<>();
                        for (Booking booking : dateBookings) {
                            int bookingStart = Integer.parseInt(booking.startTime.split(":")[0]);
                            int bookingEnd = bookingStart + booking.duration;
                            for (int hour = bookingStart; hour < bookingEnd; hour++) {
                                occupiedHours.add(hour);
                            }
                        }
                        
                        // Show available time slots (excluding occupied ones)
                        List<String> availableSlots = new ArrayList<>();
                        for (String slot : allTimeSlots) {
                            String slotStart = slot.split(" - ")[0];
                            int slotHour = Integer.parseInt(slotStart.split(":")[0]);
                            if (!occupiedHours.contains(slotHour)) {
                                availableSlots.add(slot);
                            }
                        }
                        
                        result.append("Available slots (").append(availableSlots.size()).append(" remaining):\n");
                        for (String slot : availableSlots) {
                            result.append("  ").append(slot).append("\n");
                        }
                    }
                }
            }
            
            result.append("\nQuery completed successfully!");
            queryResultsArea.setText(result.toString());
        });
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBackground(Color.WHITE);
        buttonPanel.add(queryButton);
        panel.add(buttonPanel);
        
        panel.add(Box.createVerticalStrut(15));
        
        // Results area
        JLabel resultsLabel = new JLabel("Available Time Slots:");
        resultsLabel.setFont(new Font("Arial", Font.BOLD, 18));
        panel.add(resultsLabel);
        
        queryResultsArea = new JTextArea(18, 80);
        queryResultsArea.setBackground(new Color(247, 247, 250));
        queryResultsArea.setEditable(false);
        queryResultsArea.setBorder(BorderFactory.createLineBorder(new Color(224, 225, 221)));
        queryResultsArea.setFont(new Font("Consolas", Font.PLAIN, 14));
        queryResultsArea.setText("Click 'Query Availability' to search for available time slots...");
        panel.add(new JScrollPane(queryResultsArea));
        
        return panel;
    }
    
    private JPanel createBookPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));
        panel.setBackground(Color.WHITE);
        
        JLabel title = new JLabel("Book Facility");
        title.setFont(new Font("Arial", Font.BOLD, 24));
        title.setForeground(new Color(34, 34, 59));
        panel.add(title);
        
        panel.add(Box.createVerticalStrut(15));
        
        // Facility selection
        JPanel facilityPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        facilityPanel.setBackground(Color.WHITE);
        facilityPanel.add(new JLabel("Facility Name:"));
        String[] facilities = {"Conference_Room_A", "Conference_Room_B", "Lab_101", "Lab_102", "Auditorium"};
        bookFacilityCombo = new JComboBox<>(facilities);
        bookFacilityCombo.setPreferredSize(new Dimension(200, 25));
        facilityPanel.add(bookFacilityCombo);
        panel.add(facilityPanel);
        
        panel.add(Box.createVerticalStrut(10));
        
        // Date field
        JPanel datePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        datePanel.setBackground(Color.WHITE);
        datePanel.add(new JLabel("Date (YYYY-MM-DD):"));
        bookDateField = new JTextField("2025-10-13", 15);
        datePanel.add(bookDateField);
        panel.add(datePanel);
        
        panel.add(Box.createVerticalStrut(10));
        
        // Time field
        JPanel timePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        timePanel.setBackground(Color.WHITE);
        timePanel.add(new JLabel("Start Time (HH:MM):"));
        bookTimeField = new JTextField("09:00", 15);
        timePanel.add(bookTimeField);
        panel.add(timePanel);
        
        panel.add(Box.createVerticalStrut(10));
        
        // Duration field
        JPanel durationPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        durationPanel.setBackground(Color.WHITE);
        durationPanel.add(new JLabel("Duration (hours):"));
        bookDurationField = new JTextField("1", 15);
        durationPanel.add(bookDurationField);
        panel.add(durationPanel);
        
        panel.add(Box.createVerticalStrut(15));
        
        // Book button
        JButton bookButton = new JButton("Book Facility");
        bookButton.setBackground(new Color(74, 78, 105));
        bookButton.setForeground(Color.WHITE);
        bookButton.setPreferredSize(new Dimension(200, 50));
        bookButton.setFont(new Font("Arial", Font.BOLD, 16));
        bookButton.setFocusPainted(false);
        // Simple booking logic
        bookButton.addActionListener(e -> {
            String facility = (String) bookFacilityCombo.getSelectedItem();
            String date = bookDateField.getText();
            String time = bookTimeField.getText();
            String durationStr = bookDurationField.getText();
            
            try {
                int duration = Integer.parseInt(durationStr);
                int newStart = Integer.parseInt(time.split(":")[0]);
                int newEnd = newStart + duration;
                
                // 检查时间冲突
                boolean conflict = false;
                String conflictDetails = "";
                Set<Integer> newBookingHours = new HashSet<>();
                for (int hour = newStart; hour < newEnd; hour++) {
                    newBookingHours.add(hour);
                }
                
                for (Booking existing : bookings) {
                    if (existing.facility.equals(facility) && existing.date.equals(date)) {
                        int existingStart = Integer.parseInt(existing.startTime.split(":")[0]);
                        int existingEnd = existingStart + existing.duration;
                        
                        for (int hour = existingStart; hour < existingEnd; hour++) {
                            if (newBookingHours.contains(hour)) {
                                conflict = true;
                                conflictDetails = "Time conflicts with existing booking " + existing.id;
                                break;
                            }
                        }
                        if (conflict) break;
                    }
                }
                
                if (conflict) {
                    bookResultsArea.setText("Booking FAILED!\n\n" + conflictDetails + 
                                          "\nPlease choose a different time slot.");
                } else {
                    // 创建新预订
                    String bookingId = "BK" + String.format("%010d", nextBookingId++);
                    Booking newBooking = new Booking(bookingId, facility, date, time, duration);
                    bookings.add(newBooking);
                    
                    bookResultsArea.setText("Booking SUCCESS!\n\n" +
                                          "Facility: " + facility + 
                                          "\nDate: " + date + 
                                          "\nTime: " + time + 
                                          "\nDuration: " + duration + " hours" +
                                          "\n\nConfirmation ID: " + bookingId +
                                          "\nTotal bookings: " + bookings.size() +
                                          "\n\nDEBUG: Stored date format: " + date);
                }
                
            } catch (NumberFormatException ex) {
                bookResultsArea.setText("Error: Please enter a valid duration number.");
            }
        });

        // Add button to panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBackground(Color.WHITE);
        buttonPanel.add(bookButton);
        panel.add(buttonPanel);
        
        panel.add(Box.createVerticalStrut(15));
        
        // Results area
        JLabel resultsLabel = new JLabel("Booking Result:");
        resultsLabel.setFont(new Font("Arial", Font.BOLD, 12));
        panel.add(resultsLabel);
        
        bookResultsArea = new JTextArea(8, 60);
        bookResultsArea.setBackground(new Color(247, 247, 250));
        bookResultsArea.setEditable(false);
        bookResultsArea.setBorder(BorderFactory.createLineBorder(new Color(224, 225, 221)));
        bookResultsArea.setText("Click 'Book Facility' to make a reservation...");
        panel.add(new JScrollPane(bookResultsArea));
        
        return panel;
    }
    
    private JPanel createChangePanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(Color.WHITE);
        
        JLabel title = new JLabel("Extend Booking Time");
        title.setFont(new Font("Arial", Font.BOLD, 24));
        title.setForeground(new Color(34, 34, 59));
        panel.add(title);
        
        panel.add(Box.createVerticalStrut(20));
        
        // Booking ID field
        JPanel idPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        idPanel.setBackground(Color.WHITE);
        JLabel idLabel = new JLabel("Booking ID:");
        idLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        idPanel.add(idLabel);
        changeIdField = new JTextField(15);
        changeIdField.setFont(new Font("Arial", Font.PLAIN, 14));
        changeIdField.setPreferredSize(new Dimension(150, 30));
        idPanel.add(changeIdField);
        panel.add(idPanel);
        
        panel.add(Box.createVerticalStrut(15));
        
        // Extension time field
        JPanel extensionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        extensionPanel.setBackground(Color.WHITE);
        JLabel extensionLabel = new JLabel("Extension Time (minutes):");
        extensionLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        extensionPanel.add(extensionLabel);
        JTextField extensionField = new JTextField("60", 10);
        extensionField.setFont(new Font("Arial", Font.PLAIN, 14));
        extensionField.setPreferredSize(new Dimension(100, 30));
        extensionPanel.add(extensionField);
        panel.add(extensionPanel);
        
        panel.add(Box.createVerticalStrut(20));
        
        // Extension buttons - Idempotent and Non-Idempotent
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBackground(Color.WHITE);
        
        JButton idempotentButton = new JButton("Extend (Idempotent)");
        idempotentButton.setBackground(new Color(74, 78, 105));
        idempotentButton.setForeground(Color.WHITE);
        idempotentButton.setPreferredSize(new Dimension(180, 40));
        idempotentButton.setFont(new Font("Arial", Font.BOLD, 12));
        idempotentButton.setFocusPainted(false);
        
        JButton nonIdempotentButton = new JButton("Extend (Non-Idempotent)");
        nonIdempotentButton.setBackground(new Color(220, 53, 69));
        nonIdempotentButton.setForeground(Color.WHITE);
        nonIdempotentButton.setPreferredSize(new Dimension(180, 40));
        nonIdempotentButton.setFont(new Font("Arial", Font.BOLD, 12));
        nonIdempotentButton.setFocusPainted(false);
        // Idempotent extension logic
        idempotentButton.addActionListener(e -> {
            String bookingId = changeIdField.getText().trim();
            String extensionStr = extensionField.getText().trim();
            
            if (bookingId.isEmpty() || extensionStr.isEmpty()) {
                changeResultArea.setText("Error: Please enter both Booking ID and Extension Time");
                return;
            }
            
            try {
                int extensionMinutes = Integer.parseInt(extensionStr);
                
                // Find the booking
                Booking targetBooking = null;
                int originalDuration = 0;
                for (Booking booking : bookings) {
                    if (booking.id.equals(bookingId)) {
                        targetBooking = booking;
                        // Store original duration when first extending this booking
                        if (!originalDurations.containsKey(bookingId)) {
                            originalDurations.put(bookingId, booking.duration);
                        }
                        originalDuration = originalDurations.get(bookingId);
                        break;
                    }
                }
                
                if (targetBooking == null) {
                    changeResultArea.setText("IDEMPOTENT EXTENSION RESULT:\n\n" +
                                           "Booking ID '" + bookingId + "' not found.\n" +
                                           "Same result no matter how many times you try.");
                    return;
                }
                
                // Idempotent: Always calculate from original duration + extension (convert minutes to hours properly)
                double extensionHours = extensionMinutes / 60.0;
                int targetDurationHours = originalDuration + (int) Math.ceil(extensionHours);
                
                if (targetBooking.duration == targetDurationHours) {
                    changeResultArea.setText("IDEMPOTENT EXTENSION - NO CHANGE!\n\n" +
                                           "Booking " + bookingId + " already at target duration.\n" +
                                           "Original: " + originalDuration + " hours\n" +
                                           "Extension: +" + extensionMinutes + " minutes\n" +
                                           "Current: " + targetBooking.duration + " hours\n\n" +
                                           "IDEMPOTENT: Same input → Same result");
                } else {
                    targetBooking.duration = targetDurationHours;
                    changeResultArea.setText("IDEMPOTENT EXTENSION SUCCESS!\n\n" +
                                           "Booking " + bookingId + " set to target duration.\n" +
                                           "Original: " + originalDuration + " hours\n" +
                                           "Extension: +" + extensionMinutes + " minutes\n" +
                                           "Final: " + targetDurationHours + " hours\n\n" +
                                           "IDEMPOTENT: Multiple clicks always produce " + targetDurationHours + " hours");
                }
                
            } catch (NumberFormatException ex) {
                changeResultArea.setText("Error: Please enter a valid number for extension time.");
            }
        });
        
        // Non-Idempotent extension logic
        nonIdempotentButton.addActionListener(e -> {
            String bookingId = changeIdField.getText().trim();
            String extensionStr = extensionField.getText().trim();
            
            if (bookingId.isEmpty() || extensionStr.isEmpty()) {
                changeResultArea.setText("Error: Please enter both Booking ID and Extension Time");
                return;
            }
            
            try {
                int extensionMinutes = Integer.parseInt(extensionStr);
                
                // Find the booking
                Booking targetBooking = null;
                for (Booking booking : bookings) {
                    if (booking.id.equals(bookingId)) {
                        targetBooking = booking;
                        break;
                    }
                }
                
                if (targetBooking == null) {
                    changeResultArea.setText("NON-IDEMPOTENT EXTENSION FAILED:\n\n" +
                                           "Booking ID '" + bookingId + "' not found.\n" +
                                           "Cannot extend non-existent booking.");
                    return;
                }
                
                // Non-idempotent: Add extension each time (convert minutes properly)
                int oldDuration = targetBooking.duration;
                double extensionHours = extensionMinutes / 60.0;
                // For non-idempotent: only extend if >= 30 minutes, otherwise add fractional time
                if (extensionMinutes >= 30) {
                    targetBooking.duration += (int) Math.ceil(extensionHours);
                } else {
                    // For small extensions, don't add a full hour
                    targetBooking.duration += (extensionMinutes >= 1 ? 1 : 0);
                }
                
                changeResultArea.setText("NON-IDEMPOTENT EXTENSION SUCCESS!\n\n" +
                                       "Booking " + bookingId + " extended:\n" +
                                       "Previous duration: " + oldDuration + " hours\n" +
                                       "Extension: +" + extensionMinutes + " minutes\n" +
                                       "NEW duration: " + targetBooking.duration + " hours\n\n" +
                                       "NON-IDEMPOTENT: Each click adds more time!\n" +
                                       "Duration grows with each extension request.");
                
            } catch (NumberFormatException ex) {
                changeResultArea.setText("Error: Please enter a valid number for extension time.");
            }
        });
        
        buttonPanel.add(idempotentButton);
        buttonPanel.add(nonIdempotentButton);
        panel.add(buttonPanel);
        
        panel.add(Box.createVerticalStrut(20));
        
        // Results area
        JLabel resultsLabel = new JLabel("Extension Result:");
        resultsLabel.setFont(new Font("Arial", Font.BOLD, 16));
        panel.add(resultsLabel);
        
        changeResultArea = new JTextArea(10, 70);
        changeResultArea.setBackground(new Color(247, 247, 250));
        changeResultArea.setEditable(false);
        changeResultArea.setBorder(BorderFactory.createLineBorder(new Color(224, 225, 221)));
        changeResultArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        changeResultArea.setText("Use the buttons above to extend booking time.\n\nIdempotent: Sets absolute target duration\nNon-Idempotent: Adds extension each time");
        panel.add(new JScrollPane(changeResultArea));
        
        return panel;
    }
    
    private JPanel createOperationsPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(Color.WHITE);
        
        JLabel title = new JLabel("Additional Operations");
        title.setFont(new Font("Arial", Font.BOLD, 16));
        title.setForeground(new Color(34, 34, 59));
        panel.add(title);
        
        panel.add(Box.createVerticalStrut(15));
        
        // Cancel booking section
        JPanel cancelPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        cancelPanel.setBackground(Color.WHITE);
        cancelPanel.add(new JLabel("Cancel Booking ID:"));
        cancelField = new JTextField(15);
        cancelPanel.add(cancelField);
        JButton cancelButton = new JButton("Cancel");
        cancelButton.setBackground(new Color(220, 53, 69));
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setFocusPainted(false);
        cancelButton.addActionListener(e -> {
            String bookingId = cancelField.getText().trim();
            if (bookingId.isEmpty()) {
                operationsResultsArea.setText("Error: Please enter a Booking ID to cancel.");
            } else {
                boolean found = false;
                for (int i = 0; i < bookings.size(); i++) {
                    if (bookings.get(i).id.equals(bookingId)) {
                        Booking cancelled = bookings.remove(i);
                        operationsResultsArea.setText("IDEMPOTENT CANCELLATION SUCCESS!\n\n" +
                                                    "Booking " + bookingId + " has been cancelled.\n\n" +
                                                    "Released resources:\n" +
                                                    "Facility: " + cancelled.facility + "\n" +
                                                    "Date: " + cancelled.date + "\n" +
                                                    "Time: " + cancelled.startTime + "\n" +
                                                    "Duration: " + cancelled.duration + " hours\n\n" +
                                                    "✓ IDEMPOTENT: First cancellation removes booking" +
                                                    "\n✓ Subsequent cancellations return same 'not found' result" +
                                                    "\n✓ System state updated: " + bookings.size() + " remaining bookings" +
                                                    "\n✓ Time slots now available for new bookings");
                        cancelField.setText("");
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    // 幂等性：取消不存在的预订应该返回相同结果
                    operationsResultsArea.setText("IDEMPOTENT CANCELLATION SUCCESS!\n\n" +
                                                "Booking ID '" + bookingId + "' not found.\n\n" +
                                                "Possible reasons:\n" +
                                                "• Booking was already cancelled\n" +
                                                "• Booking ID never existed\n" +
                                                "• Previous cancellation request succeeded\n\n" +
                                                "✓ IDEMPOTENT: Multiple cancellation attempts" +
                                                "\n  produce the same result: booking does not exist" +
                                                "\n✓ System state consistent: " + bookings.size() + " active bookings" +
                                                "\n✓ No side effects from repeated operations");
                }
            }
        });
        cancelPanel.add(cancelButton);
        panel.add(cancelPanel);
        
        panel.add(Box.createVerticalStrut(15));
        
        // List bookings button
        JButton listButton = new JButton("List All Bookings");
        listButton.setBackground(new Color(74, 78, 105));
        listButton.setForeground(Color.WHITE);
        listButton.setPreferredSize(new Dimension(150, 35));
        listButton.setFocusPainted(false);
        listButton.addActionListener(e -> {
            StringBuilder result = new StringBuilder();
            result.append("Current Bookings:\n\n");
            
            if (bookings.isEmpty()) {
                result.append("No bookings found.\n\nAll facilities are available for booking!");
            } else {
                for (int i = 0; i < bookings.size(); i++) {
                    Booking booking = bookings.get(i);
                    int endHour = Integer.parseInt(booking.startTime.split(":")[0]) + booking.duration;
                    result.append((i + 1)).append(". ").append(booking.id)
                          .append(" - ").append(booking.facility)
                          .append(" - ").append(booking.date)
                          .append(" ").append(booking.startTime)
                          .append("-").append(String.format("%02d:00", endHour))
                          .append("\n");
                }
                result.append("\nTotal: ").append(bookings.size()).append(" active bookings");
            }
            
            operationsResultsArea.setText(result.toString());
        });
        JPanel listButtonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        listButtonPanel.setBackground(Color.WHITE);
        listButtonPanel.add(listButton);
        panel.add(listButtonPanel);
        
        panel.add(Box.createVerticalStrut(15));
        
        // Results area
        JLabel resultsLabel = new JLabel("Operation Results:");
        resultsLabel.setFont(new Font("Arial", Font.BOLD, 12));
        panel.add(resultsLabel);
        
        operationsResultsArea = new JTextArea(8, 60);
        operationsResultsArea.setBackground(new Color(247, 247, 250));
        operationsResultsArea.setEditable(false);
        operationsResultsArea.setBorder(BorderFactory.createLineBorder(new Color(224, 225, 221)));
        operationsResultsArea.setText("Use the buttons above to perform additional operations...");
        panel.add(new JScrollPane(operationsResultsArea));
        
        return panel;
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new SimpleGUI().setVisible(true);
            System.out.println("Java GUI Client started successfully!");
        });
    }
}